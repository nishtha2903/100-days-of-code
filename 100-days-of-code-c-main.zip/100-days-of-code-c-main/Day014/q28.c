//Write a program to print the product of even numbers from 1 to n.
#include <stdio.h>
int main()
{
    int n, i;
    long long product = 1;
    printf("Enter a number: ");
    scanf("%d", &n);
    for(i = 2; i <= n; i = i + 2)
    {
        product = product * i;
    }
    printf("Product of even numbers = %lld\n", product);
    return 0;
}